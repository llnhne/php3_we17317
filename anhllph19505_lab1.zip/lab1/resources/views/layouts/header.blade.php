<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Trang Chủ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/lien-he">Liên Hệ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/thongtinsv/lananh">Thông Tin SV</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

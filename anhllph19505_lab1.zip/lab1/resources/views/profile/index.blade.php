@extends('layouts.app')

@section('content')
    <h1 class="mt-5 text-center">Đây là trang chủ</h1>
@endsection

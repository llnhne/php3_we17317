@extends('layouts.app')

@section('content')
    <h1 class="mt-5 text-center">Đây là trang hiện chi tiết của tin có id là: {{ $id }}</h1>
@endsection

@extends('layouts.app')

@section('content')
    <h1 class="mt-5 text-center">Đây là trang liên hệ</h1>
@endsection

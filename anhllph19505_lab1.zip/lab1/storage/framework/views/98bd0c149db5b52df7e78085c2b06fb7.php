

<?php $__env->startSection('content'); ?>
    <h1 class="mt-5 text-center">Đây là trang chủ</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\php3-laravel\lab1\resources\views/profile/index.blade.php ENDPATH**/ ?>
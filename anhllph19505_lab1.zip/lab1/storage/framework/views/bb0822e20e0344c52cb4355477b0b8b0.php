
<?php /**PATH C:\laragon\www\php3-laravel\lab1\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
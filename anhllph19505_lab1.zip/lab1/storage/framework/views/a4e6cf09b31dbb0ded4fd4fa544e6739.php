

<?php $__env->startSection('content'); ?>
    <h1 class="mt-5 text-center">Đây là trang giới thiệu thông tin SV</h1>
    <p class="mt-3 text-center">My name's <?php echo e($name); ?>. I'm 21 years old this year and live in Hanoi. I'm currently learning web programming at fpoly college.</p>
    <table class="table table-bordered text-center mt-3">
        <thead class="table-primary">
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Birthday</th>
            <th scope="col">Phone Number</th>
            <th scope="col">Address</th>
            <th scope="col">City</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row"><?php echo e($id); ?></th>
            <td><?php echo e($name); ?></td>
            <td><?php echo e($birthday); ?></td>
            <td><?php echo e($phone); ?></td>
            <td><?php echo e($address); ?></td>
            <td><?php echo e($city); ?></td>
          </tr>
        </tbody>
      </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\php3-laravel\lab1\resources\views/profile/thongtinsv.blade.php ENDPATH**/ ?>
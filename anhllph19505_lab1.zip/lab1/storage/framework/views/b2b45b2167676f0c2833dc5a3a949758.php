<h1>đây là trang liên hệ</h1>
<?php /**PATH C:\laragon\www\php3-laravel\lab1\resources\views/lienhe.blade.php ENDPATH**/ ?>